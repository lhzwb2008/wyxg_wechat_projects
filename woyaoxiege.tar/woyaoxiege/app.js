// app.js
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        wx.request({
          url: 'https://woyaoxiege.cn/code/getOpenid2.php', 
          data: {
            code:res.code
          },
          header: {
            'content-type': 'application/json' // 默认值
          },
          success:(res) =>{
            wx.setStorage({
              key:'openid',
              data:res.data
            })
            console.log("write openid:"+res.data)
          }
        })
      }
    })
  },
  globalData: {
    userInfo: null
  }
})
